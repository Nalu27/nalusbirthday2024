# Birthday candle

A Pen created on CodePen.io. Original URL: [https://codepen.io/ggglll/pen/oJbMja](https://codepen.io/ggglll/pen/oJbMja).

Make a wish

.. and click the flame to make it happen :)